The text-html.png file is from the Tango Desktop Project
(http://tango.freedesktop.org/).

It is licensed under the Creative Commons Attribution
Share-Alike 2.5 License (http://creativecommons.org/licenses/by-sa/2.5/),
which is in the LICENSE.icons.txt file.

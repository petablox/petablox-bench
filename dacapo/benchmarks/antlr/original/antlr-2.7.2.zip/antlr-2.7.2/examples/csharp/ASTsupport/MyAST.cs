/// <summary>Test homogeneous class.</summary>
public class MyAST : antlr.CommonAST 
{
}

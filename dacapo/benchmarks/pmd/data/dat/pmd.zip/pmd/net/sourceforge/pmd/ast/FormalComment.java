package net.sourceforge.pmd.ast;

public class FormalComment extends Comment {

    public FormalComment(Token t) {
        super(t);
    }

}

package tinybasic;

class FunctionScope extends Scope{
    public FunctionScope(Scope prev){
	super(prev);
    }


}
